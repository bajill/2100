import p1.Scanner;


class Main{
    public static void main(String args[]){
        p1.Scanner.readToken();
    }
}
