package p1;

public enum TokenKind{
    addToken("+"),
    intValToken("number"),
    subtractToken("-"),
    multiplyToken("*"),
    divideToken("/"),
    leftParToken("("),
    rightParToken(")");

    TokenKind(String im){
        image = im;
    }
    private String image;

    public String identify(){
    return image + " token";
    }
}
