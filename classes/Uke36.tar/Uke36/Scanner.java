package p1;
import p1.Token;
import java.util.ArrayList;
public class Scanner{
    ArrayList<Token> tokens = new ArrayList<Token>();
    String line = "1+3/4*(2-5)";
    public static void curToken(){
        for(int i = 0; i < line.length(); i++){
            if(line.charAt(i).equals("0-9"))
                tokens.add(new Token(line.charAt(i)));
            else
                tokens.add(new Token(line.charAt(i)));
        }
    }

}
