package p1;
import p1.TokenKind;

public class Token{
    public String id;
    public TokenKind kind;
    public int intval;

    Token (TokenKind k){
        kind = k;
    }

    Token (String s){

        if(s.equals("+"))
            kind = new TokenKind.addToken();
        else if(s.equals("-"))
            kind = new subtractToken();
        else if(s.equals("*"))
            kind = new multiplyToken();
        else if(s.equals("/"))
            kind = new divideToken();
        else if(s.equals("("))
            kind = new leftParToken();
        else
            kind = new rightParToken();

        id = s;
    }
    Token(int n){
        kind = intValToken;
        intVal = n;
    }


}
